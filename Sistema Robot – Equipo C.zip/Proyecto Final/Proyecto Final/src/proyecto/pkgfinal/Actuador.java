/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package proyecto.pkgfinal;


/**
 *
 * @author valentina
 */
public class Actuador {
    private int id;
    private String tipo;
    private String descripcion;
    
    private Altavoz altavoz;

    public Actuador(int id, String tipo, String descripcion) {
        this.id = id;
        this.tipo = tipo;
        this.descripcion = descripcion;
        this.altavoz = altavoz;
    }

    public int realizar_accion(){
        return 0;
    }
}

